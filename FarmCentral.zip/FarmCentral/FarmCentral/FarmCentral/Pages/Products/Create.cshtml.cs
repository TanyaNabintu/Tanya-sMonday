using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace FarmCentral.Pages.Products
{
    public class CreateModel : PageModel
    {
        public ProductInfo productInfo = new ProductInfo();
        public String errorMessage = "";
        public String successMessage = "";
        public void OnGet()
        {
        }
        public void OnPost()
        {
            productInfo.productName = Request.Form["productName"];
            productInfo.quantity = Request.Form["quantity"];
            productInfo.price = Request.Form["price"];

            if (productInfo.productName.Length == 0||  productInfo.quantity.Length == 0|| 
                productInfo.price.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }
            // Data needs to be saved in the database
            try
            {
                String connectionString = "Server=tcp:farmcentralsql.database.windows.net,1433;Initial Catalog=FARMCENTRAL-SQL-DB;Persist Security Info=False;User ID=Tanya;Password=admin@1234;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
                using (SqlConnection connection = new SqlConnection(connectionString)) 
                {
                    connection.Open();
                    String sql = "INSERT INTO Products" +
                        "(productName,quantity,price) VALUES " +
                        "(@productName,@quantity,@price);";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@productName", productInfo.productName);
                        command.Parameters.AddWithValue("@quantity", productInfo.quantity);
                        command.Parameters.AddWithValue("@price", productInfo.price);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex) 
            {
                errorMessage = ex.Message;
                return;
            }

            productInfo.productName = "";
            productInfo.quantity = "";
            productInfo.price = "";
            successMessage = "New product added correctly";

            Response.Redirect("/Products/Index");
        }
    }
}
