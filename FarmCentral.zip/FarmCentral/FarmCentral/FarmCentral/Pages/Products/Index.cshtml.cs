using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace FarmCentral.Pages.Products
{
   
    public class IndexModel : PageModel
    {
        
        private List<ProductInfo> list = new List<ProductInfo>();
        public void OnGet()
        {
           
        }

        public List<ProductInfo> table()
        {
            try
            {
                string connectionString = " Server=tcp:farmcentralsql.database.windows.net,1433;Initial Catalog=FARMCENTRAL-SQL-DB;Persist Security Info=False;User ID=Tanya;Password=admin@1234;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "SELECT * FROM Product ";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                           
                            while (reader.Read())
                            {

                                list.Add(new ProductInfo()
                                {

                                    productName = reader.GetString(1),
                                    date = reader.GetDateTime(2).ToString(),
                                    quantity = reader.GetString(3),
                                    price = reader.GetString(4),
                                });




                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
            return list;
        }
    }
    public class ProductInfo
    {
        public string id;
        public string productName;
        public string date;
        public string quantity;
        public string price;
    }
}
