using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace FarmCentral.Pages.Products
{
    public class EditModel : PageModel
    {
        public ProductInfo productInfo = new ProductInfo();
        public String errorMessage = "";
        public String successMessage = "";
        public void OnGet()
        {
            String id= Request.Query["id"];
            try
            {
                String connectionString = "Data Source=farmcentralsql.database.windows.net;Initial Catalog=FARMCENTRAL-SQL-DB;Persist Security Info=True;User ID=Tanya;Password=***********";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM Products WHERE id=@id";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                       using (SqlDataReader reader = command.ExecuteReader()) 
                        {
                            if (reader.Read()) 
                            {
                                productInfo.id = "" + reader.GetInt32(0);
                                productInfo.productName = reader.GetString(1);
                                productInfo.quantity = reader.GetString(2);
                                productInfo.price = reader.GetString(3);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            { 
                errorMessage = ex.Message;
            }
        }
        public void OnPost()
        { 
            productInfo.id= Request.Form["id"];
            productInfo.productName = Request.Form["productName"];
            productInfo.quantity = Request.Form["quantity"];
            productInfo.price = Request.Form["price"];

            if (productInfo.id.Length == 0|| productInfo.productName.Length == 0 || 
                productInfo.quantity.Length == 0 ||productInfo.price.Length == 0) 
            {
                errorMessage = "All the fields are required";
                return;
            }

            try
            {
                String connectionString = "Data Source=farmcentralsql.database.windows.net;Initial Catalog=FARMCENTRAL-SQL-DB;Persist Security Info=True;User ID=Tanya;Password=***********";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "UPDATE Products" +
                        "SET productName=@productName, quantity=@quantity, price=@price " +
                        "WHERE id=@id";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@productName", productInfo.productName);
                        command.Parameters.AddWithValue("@quantity", productInfo.quantity);
                        command.Parameters.AddWithValue("@price", productInfo.price);
                        command.Parameters.AddWithValue("@id", productInfo.id);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

            Response.Redirect("/Products/Index");
        }
    }
}
